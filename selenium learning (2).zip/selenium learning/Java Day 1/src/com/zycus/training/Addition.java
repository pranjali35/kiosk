/**
 * 
 */
package com.zycus.training;

import java.util.Scanner;

/**
 * @author pranjali.telawane
 *
 */
public class Addition {
	public int no1=2, no2=3;
	//default constructor
	public Addition()
	{
		no1=5;
		no2=6;
	}
	//parameterized constructor
	
	public Addition(int no1, int no2)
	{
		this.no1=no1;
		this.no2=no2;
	}
	public void add()
	{
		int sum = no1 + no2;
		System.out.println("sum: "+sum );
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Addition addition =new Addition();
		addition.add();
	    Addition addition2 = new Addition(2,2);
	    addition2.add();
	    Scanner scanner = new Scanner(System.in);
	    System.out.println("Enter Value:");
	     int a = scanner.nextInt();
	     int b = scanner.nextInt();
	     System.out.println("a:" +a);
	     System.out.println("b:" +b);
	     Addition add = new Addition(a,b);
	     add.add();
	     
	    
	}

}
