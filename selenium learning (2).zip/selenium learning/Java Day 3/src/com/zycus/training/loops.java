package com.zycus.training;

public class loops {

	public static void main(String args[]) {
		String[] names = { "ABC", "XYZ", "PQR" };

		// for(DataType variableName : list/array)
		for (String var : names) {
			if(var.equalsIgnoreCase("XYZ"))
			{
				continue;
			}
			System.out.println(var);
		}

		int[] nos = { 1,2,3};

		// for(DataType variableName : list/array)
		for (int no : nos) {
			System.out.println(no);
		}
		
		//While loop
		int i =0;
		while (i<5)
		{
			System.out.println("i=" +i);
			i++;
		}
	//Do While		
		int j=8;
				do
				{
					System.out.println("j=" +j);
					j--;
				}
				while(j!=0);
				}


	}


