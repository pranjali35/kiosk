package com.zycus.training;

import java.util.Scanner;

public class Requisition extends Documents {
	
    String Reason;
	String Supp_comments;
	String Settlement_via;
	

	public Requisition()
	{
	 String Reason = "Maintenance";
	 String Supp_comments="Done";
	 String Settlement_via="Invoice";
	}
	
	public Requisition(String Reason,String Supp_comments, String Settlement_via )
	{
	 this.Reason=Reason;
	 this.Supp_comments=Supp_comments;
	 this.Settlement_via=Settlement_via;
	}
	Documents d = new Documents();
	public void get_req_details()
	{
		d.accept_document_details();
		Scanner scanner1 = new Scanner(System.in);
		System.out.println("Enter Reason:");
		Reason = scanner1.next();
		System.out.println("Enter Supp_comments:");
		Supp_comments = scanner1.next();
		System.out.println("Enter Settlement_via:");
		Settlement_via = scanner1.next();
		scanner1.close();
	}
	
	public void show_req_details()
	{
		d.show_document_details();
		System.out.println();
		System.out.println("Reason:" +Reason);
	    System.out.println("Supplier comments:"+Supp_comments);
		System.out.println("Settlement_via:"+Settlement_via);
	}
	
	

}
