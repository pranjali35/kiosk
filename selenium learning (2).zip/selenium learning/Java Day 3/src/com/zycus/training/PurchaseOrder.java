

package com.zycus.training;

import java.util.Scanner;

//supplier
//buyer
//reference

public class PurchaseOrder extends Documents {
	
    String supplier;
	String buyer;
	String reference;
	

	public PurchaseOrder()
	{
	 String supplier = "Maintenance";
	 String buyer="Done";
	 String reference="Invoice";
	}
	
	public PurchaseOrder(String supplier,String buyer, String reference )
	{
	 this.supplier=supplier;
	 this.buyer=buyer;
	 this.reference=reference;
	}
	Documents d = new Documents();
	public void get_po_details()
	{
		d.accept_document_details();
		Scanner scanner1 = new Scanner(System.in);
		System.out.println("Enter Supplier:");
		supplier = scanner1.next();
		System.out.println("Enter Buyer:");
		buyer = scanner1.next();
		System.out.println("Enter Reference:");
		reference = scanner1.next();
		scanner1.close();
	}
	
	public void show_po_details()
	{
		d.show_document_details();
		System.out.println();
		System.out.println("supplier:" +supplier);
	    System.out.println("buyer:"+buyer);
		System.out.println("Reference:"+reference);
	}
	
	

}
