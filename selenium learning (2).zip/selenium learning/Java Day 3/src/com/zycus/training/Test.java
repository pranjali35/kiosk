package com.zycus.training;
import java.util.Scanner;
public class Test {

	public static void main(String args[]) {
	System.out.println("Select the type of document you wish to create:");
	System.out.println("1. Requisition");
	System.out.println("2. PurchaseOrder");
	Scanner scanner = new Scanner(System.in);
	int ch = scanner.nextInt();
	Documents d1 = new Documents();
	Requisition r1=new Requisition();
	PurchaseOrder p1=new PurchaseOrder();

	switch (ch) {
	case 1:
		r1.get_req_details();
		r1.show_req_details();
		break;
	case 2:
		p1.get_po_details();
		p1.show_po_details();
		break;
	default:
	   System.out.println("Thank You!");
	

	}

}
}

