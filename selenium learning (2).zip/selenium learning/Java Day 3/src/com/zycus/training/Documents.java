package com.zycus.training;

import java.util.Scanner;

public class Documents {
	int docno;
	String docname;
	String status;
//	String[] items = new String[5];
	String[][] item=new String[3][3];
	int i=0;
	int k=0;
	

	public Documents() {
		int docno = 1;
		String docname = "Req";
		String status = "Draft";
//		String[] items = { "ab", "pq", "kj", "lk", "pt" };
		item[0][0]= "a";
		item[0][1]= "b";
		item[0][2]= "c";
		item[1][0]= "d";
		item[1][1]= "e";
		item[1][2]= "f";
		
		
	}

	public Documents(int docno, String docname, String status, String[][] items) {
		this.docno = docno;
		this.docname = docname;
		this.status = status;
		this.item = items;
	}

	public void accept_document_details() {
//		
//		int noOfRows = 2, noOfCols = 2;
//		int[][] sum = new int[noOfRows][noOfCols];
//		sum[0][0] = 2;
//		sum[0][1] = 5;
//		sum[1][0] = 8;
//		sum[1][1] = 9;
//
//		for (i = 0; i < 2; i++) {
//			for (int j = 0; j < 2; j++) {
//				System.out.print(sum[i][j] + " ");
//			}
//			System.out.println();
//		}

		Scanner scanner1 = new Scanner(System.in);
		System.out.println("Enter Docno:");
		docno = scanner1.nextInt();
		System.out.println("Enter Doc name:");
		docname = scanner1.next();
		System.out.println("Enter Status:");
		status = scanner1.next();
		System.out.println("Enter the number of Items you wish to order:");
		int no = scanner1.nextInt();
		
		for(int i=0; i<no;i++)
		{
			System.out.println("Enter Type of item:");
			Scanner scan = new Scanner(System.in);
			String Type=scan.next();
			item[i][k]=Type;
			System.out.println("Enter Item name:");
			String item_name=scan.next();
			item[i][k+1]=item_name;
			
			}
		}
		
		
//		System.out.println("Enter Items:");
//		int i = 0;
//		while (scanner1.hasNext()) {
//			items[i] = scanner1.next();
//			i++;
//			if (i == 5) {
//				System.out.println("Limit of Five Items Reached!!");
//				break;
//			}
//		}


	public void show_document_details() {
		System.out.println("Docno:" + docno);
		System.out.println("Doc name:" + docname);
		System.out.println("Status:" + status);
		System.out.println("Items:"+item[i][k]);
//		for(String var:items)
//		{
//		System.out.print(var+ " ");
//		}
	}


	}


