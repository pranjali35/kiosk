package com.zycus.training;
public class PermanentEmployee extends Employee{
	int ctc;
	public PermanentEmployee()
	{
		ctc=300000;
	
	}
	
	public PermanentEmployee(int EId, String EName, int CTC)
	{
		super(EId, EName);
		ctc=CTC;
	}
	public void show()
	{
		super.show();
		System.out.println("ctc:" + ctc);
	}
	

}
