

public  class Arrays {
	
	void show(int[] x)
	{
		int i =0;
		for (i = 0; i < x.length; i++) {
			System.out.println(x[i]);
		}
	}
	

	public static void main(String[] args) {
		int[] a = new int[3];
		a[0] = 1;
		a[1] = 3;
		a[2] = 5;

		int i = 0;
		for (i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
		String[] names = new String[4];
		names[0] = "ABC";
		names[1] = "PQR";
		names[2] = "XYZ";
		names[3] = "ASD";
		for (i = 0; i < names.length; i++) {
			System.out.println(names[i]);
		}
		Arrays array =new Arrays();
		array.show(a);
		
		int[][] sum = new int[2][2];
		sum[0][0] =2;
		sum[0][1] =4;
		sum[1][0] =6;
		sum[1][1] =8;
		
		for (i=0; i<2;i++)
		{
			for(int j=0; j<2; j++)
			{
				System.out.print(sum[i][j] + " ");
			}
			System.out.println();
		}	
			}
		
		
		
	}

