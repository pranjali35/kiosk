package com.zycus.training;
public class Employee {

	int EmpId;
	String EmpName;
	
	public Employee()
	{
		EmpId=1;
		EmpName="XYZ";
	}
	
	public Employee(int EId, String EName)
	{
		EmpId=EId;
		EmpName=EName;
	}
	public void show()
	{
		System.out.println("EmpId:" + EmpId);
		System.out.println("EmpName:" + EmpName);
	}
	
}
