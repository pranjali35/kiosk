package com.zycus.training;

public class TestInheritance {
	
	
	public static void main(String args[])
	{
		PermanentEmployee pEmp = new PermanentEmployee();
		pEmp.show();
	}

}
